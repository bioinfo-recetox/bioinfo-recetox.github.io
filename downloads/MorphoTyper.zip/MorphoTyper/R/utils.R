write.cibersortx.expression = function(X, filename)
{
  # Given an expression matrix with genes by rows and samples by columns,
  # save it in a file (.txt) suitable for CibersortX analyses.
  #
  # X : expression data, genes x samples. If max(X) < 20, it is assumed it
  #     represents log2-transformed data and it will - per CibersortX
  #     requirements - transformed back via 2^X.
  # file: file the data will be written to.

  if (max(X) < 20) X = 2^X
  d = as.data.frame(cbind(rownames(X), X))
  colnames(d)[1] = "Gene"
  rownames(d) = NULL

  write.table(d, file=filename, quote=FALSE, sep='\t', row.names=FALSE)
}


load.morpho.signatures = function(deconvolver="all")
{
  # Read signature matrices associated with different methods of in silico
  # deconvolution of the bulk expression data.

  deconv = c("cibersortx")      # all available methods
  n_data_files = c(2)           # number of signature matrices per method
  names(n_data_files) = deconv

  if (str_to_lower(deconvolver) == 'all') decs = deconv
  else decs = str_to_lower(deconvolver)

  decs = intersect(decs, deconv)  # keep only known methods

  sigs = list()

  for (d in decs) {
    for (k in 1:n_data_files[d]){
      s = sprintf("%s_%d", d, k)
      f = sprintf("./data/profiles_%s.rds", s)
      sigs[[s]] = readRDS(f)
    }
  }

  return (sigs)
}
