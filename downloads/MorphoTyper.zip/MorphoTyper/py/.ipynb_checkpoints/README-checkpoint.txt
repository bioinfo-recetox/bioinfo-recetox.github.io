Main dependencies:

- Pandas
- NumPY
- AutoGeneS: https://github.com/theislab/AutoGeneS
- fastparquet