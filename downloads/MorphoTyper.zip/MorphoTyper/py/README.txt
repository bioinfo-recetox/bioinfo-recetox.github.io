Main dependencies:

- Pandas
- NumPY
- AutoGeneS: https://github.com/theislab/AutoGeneS
- fastparquet

Please unzip the model file (autogenes_*.obj.gz) prior to running the deconvolution.
